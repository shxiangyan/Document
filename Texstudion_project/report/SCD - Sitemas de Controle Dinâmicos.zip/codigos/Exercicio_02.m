% LIMPANDO DADOS DO MATLAB
clc; clear; close all;
% VETOR DE DADOS OU MEDICOES
x = [0 1 2 3 4 5 6];
y = [4499 15205 37808 75336 130799 208281 240749];
b_y = y;
% TRANSFORMACAO Y = P*E^(K*X) <=> LN(Y) = LN(P) + LN(K*X)
y = log(y);
% LETRA A)
% GERANDO MATRIZ LINEAR [x 1]
mat_a = ones(length(x),2);
mat_a(:,1) = x';
% FORMULA DO METODO DOS MININOS QUADRADOS
p = (inv(mat_a'*mat_a)*mat_a')*y'
p(2) = exp(p(2))
% OBTENDO DADOS/PREVISOES DO MODELO EXPONENCIAL
exponencial = p(2)*exp(p(1)*x);
% CALCULO DO ERRO
erro_7 = abs(b_y - exponencial)
erro_quadratico_7 = ( (b_y(1) - exponencial(1))^2 + (b_y(2) - exponencial(2))^2 + (b_y(3) - exponencial(3))^2 + (b_y(4) - exponencial(4))^2 + (b_y(5) - exponencial(5))^2 + (b_y(6) - exponencial(6))^2 + (b_y(7) - exponencial(7))^2 ) / 4
% PREPARANDO MATRIZ DE DADOS E GRAFICO
plot_ = ones(length(x), 2);
plot_(:,1) = exponencial;
plot_(:,2) = b_y;
plot(x, plot_, '-*');
legend('Linear','Dados');