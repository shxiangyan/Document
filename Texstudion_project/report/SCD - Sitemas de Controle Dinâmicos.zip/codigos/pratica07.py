#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep  4 15:14:06 2019

@author: egmon

Fontes:
http://www2.unirio.br/unirio/ccet/profmat/tcc/TCC_JOAO.pdf
http://www.decom.ufop.br/marcone/Disciplinas/MetodosNumericoseEstatisticos/QuadradosMinimos.pdf
https://www.portugal-a-programar.pt/forums/topic/47019-gerar-gr%C3%A1ficos-com-python/
https://fenix.ciencias.ulisboa.pt/downloadFile/2251937252639182/LabNum_2018_v4.pdf

"""

from numpy import matrix
import numpy as np
import matplotlib.pyplot as plt
import os
import math

def calculo(X,Y,a,b,n,m,t,p):
    '''
    CALCULOS
    O = [XT*X]^{-1} . XT . Y
    '''
    C = (((X.T) * (X)).I) * ((X.T) * Y)
    D = C.A1
    if n == 1:
        if len(D) == 2 and p == 1:
            print('theta 1 = %0.4f' %D[0])
            print('theta 2 = %0.4f' %D[1])
        elif len(D) == 3 and p == 1:
            print('\ntheta 1 = %0.4f' %D[0])
            print('theta 2 = %0.4f' %D[1])
            print('theta 3 = %0.4f' %D[2])
    W = X.A1
    Z = []
    for i in range(len(W)):
        if i % 2 == 0:
            Z.append(W[i])

    for i in range(len(W)):
        if i % 2 == 0:
            Z.append(W[i])

    if n == 1:
        graficoReta(Z,Y,D,a,b,m)

    return proj(Y,D[0],D[1],t)

def proj(Y,a,b,t):
    sal = a * (t - 1) + b
    return sal


def graficoReta(X,Y,D,a,b,m):
    i = 0
    x = []
    y = []
    x = np.linspace(a,b,100)
    while i < 100:
        y.append(D[0]*(x[i]) + D[1])
        i += 1
    if m == 0:
        plt.plot(x,y)
        plt.plot(Y)
        plt.xlabel("X")
        plt.ylabel("Y")
        plt.show()

def eqDiferencial(X,Y,t,a,b):
    W = X.A1
    Z = []
    for i in range(len(W)):
        if i % 2 == 0:
            Z.append(W[i])
    plt.plot(Z,Y)
    plt.xlabel("X")
    plt.ylabel("Y")
    plt.show()
    k = math.log(Y[5])/math.log(Y[0])
    print('k =',k)
    z = Y[0] * math.exp(k * t)
    print('Y(%d) = %0.2f' %(t,z))        


if __name__ == '__main__':
    os.system('clear')
    os.system('clear')
    m = 0#1 nao imprime o grafico 0 Imprime o grafico
    Salarios = matrix( [[151],[180],[200],[240],[260],[300],[350],[380],[415],
    [465],[510],[545],[622],[678],[724],[788],[880],[937],[954]] )
    ano = 15
    t = ano
    tam = len(Salarios)-ano
    print("1)\na)")
    Error = []
    for i in range(tam):
        X = matrix( [[-1,1],[0,1],[1,1],[2,1]] )
        Y = matrix( [[151],[180],[200],[240]] )
        XA = X
        YA = Y
        a = 0
        b = len(Y)
        c = 2000 + t
        sal = calculo(X,Y,a,b,i + 1,m,t,1)
        Error.append(sal)
        print('Salario em %d = R$%0.2f' %(c,Salarios[t]))
        print("Projecao para %d com %d dados = R$%0.2f\n" %(c,len(Y),sal))
        t += 1
    erro = 0
    for i in range(tam):
        erro += abs(Error[i]-Salarios[ano])
    print('\ne)')
    print('Erro = %0.3f\n' %(erro/len(Y)))

    t = ano
    print('\nb)')
    Error = []
    for i in range(tam):
        X = matrix( [[-1,1],[0,1],[1,1],[2,1],[3,1],[4,1],[5,1],[6,1]] )
        Y = matrix( [[151],[180],[200],[240],[260],[300],[350],[380]] )
        XB = X
        YB = Y
        a = 0
        b = len(Y)
        c = 2000 + t
        sal = calculo(X,Y,a,b,i + 1,m,t,1)
        Error.append(sal)
        print('Salario em %d = R$%0.2f' %(c,Salarios[t]))
        print("Projecao para %d com %d dados = R$%0.2f\n" %(c,len(Y),sal))
        t += 1
    erro = 0
    for i in range(tam):
        erro += abs(Error[i]-Salarios[ano])
    print('\ne)')
    print('Erro = %0.3f\n' %(erro/len(Y)))

    t = ano
    print('\nc)')
    Error = []
    for i in range(tam):
        X = matrix( [[-1,1],[0,1],[1,1],[2,1],[3,1],[4,1],[5,1],[6,1],
        [7,1],[8,1],[9,1],[10,1],[11,1],[12,1],[13,1]] )
        Y = matrix( [[151],[180],[200],[240],[260],[300],[350],[380],
        [415],[465],[510],[545],[622],[678],[724]] )
        XC = X
        YC = Y
        a = 0
        b = len(Y)
        c = 2000 + t
        sal = calculo(X,Y,a,b,i + 1,m,t,1)
        Error.append(sal)
        print('Salario em %d = R$%0.2f' %(c,Salarios[t]))
        print("Projecao para %d com %d dados = R$%0.2f\n" %(c,len(Y),sal))
        t += 1
    erro = 0
    for i in range(tam):
        erro += abs(Error[i]-Salarios[ano])
    print('\ne)')
    print('Erro = %0.3f\n' %(erro/len(Y)))

    print('\nd)')
    print('Sim, pois quantos mais dados, mais confiavel se torna a projecao.')

    print('\n2)')
    X = [1,2,3,4,5,6,7]
    Y = [4499,15205,37808,75336,130799,208281,240749]

    ajuste = 0
    if ajuste == 0:
        Yln = []
        for i in range(len(Y)):
            Yln.append(math.log(Y[i]))
        soma1 = 0
        for i in range(len(X)):
            soma1 += X[i]**2
        soma2 = 0
        for i in range(len(X)):
            soma2 += X[i]*Yln[i]
        print('%da + %0.2fb = %0.2f' %(len(X),sum(X),sum(Yln)))
        print('%0.2fa + %0.2fb = %0.2f' %(sum(X),soma1,soma2))
        a1 = -soma1 * len(X)
        c1 = -soma1 * sum(Yln)
        a2 = sum(X) * sum(X)
        c2 = sum(X) * soma2
        a = (c1 + c2)/(a1 + a2)
        print('\na = %0.4f' %a)
        b = (sum(Yln) - len(X) * a)/sum(X)
        print('b = %0.4f' %b)
        print('\ny = %0.0fe^%0.1fx' %(math.exp(a),b))
        t = 6
        y = math.exp(a) * math.exp(b * (t))
        print('\nProjecao para 2000 e \t= %d' %(y))
        print('Dado na Tabela \t\t= %d' %Y[t - 1])
        print('\t\t\t--------')
        print('Diferenca \t\t= %d' %(abs(y - Y[t - 1])))
        erro = abs(y - Y[t - 1])/t
        print('Erro = %0.4f' %erro)
        erro = math.sqrt(((y - Y[t - 1])**2)/t)
        print('Erro Quadratico = %0.4f' %erro)
        t = 7
        y = math.exp(a) * math.exp(b * (t))
        print('\nProjecao para 2010 e \t= %d' %(y))
        print('Dado na Tabela \t\t= %d' %Y[t - 1])
        print('\t\t\t--------')
        print('Diferenca \t\t= %d' %(abs(y - Y[t - 1])))
        erro = abs(y - Y[t - 1])/t
        print('Erro = %0.4f' %erro)
        erro = math.sqrt(((y - Y[t - 1])**2)/t)
        print('Erro Quadratico = %0.4f' %erro)

    if ajuste == 1:
        soma1 = 0
        for i in range(len(X)):
            soma1 += X[i]**2
        soma2 = 0
        for i in range(len(X)):
            soma2 += X[i]*Y[i]
        aux = 3.9070
        print('%da + %0.2fb = %0.2f' %(len(X),sum(X),aux))
        print('%0.2fa + %0.2fb = %0.2f' %(sum(X),soma1,soma2))
        a1 = -soma1 * len(X)
        c1 = -soma1 * aux#sum(Yln)
        a2 = sum(X) * sum(X)
        c2 = sum(X) * soma2
        a = (c1 + c2)/(a1 + a2)
        print('a = %0.4f' %a)
        b = (aux - len(X) * a)/sum(X)
        print('b = %0.4f' %b)
        print('y = %0.4f + (%0.4f)x' %(a,b))
