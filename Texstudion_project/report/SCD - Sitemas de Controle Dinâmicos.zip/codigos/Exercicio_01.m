% LIMPANDO DADOS DO MATLAB
clc; clear; close all;
% LETRA A)
x = [0 1 2 3];
y = [151 180 200 240];
[c_a] = polyfit(x, y, 1);
mat_a = ones(length(x),2);
mat_a(:,1) = x';
linear = mat_a*c_a';
x = [15 16 17 18];
y = [788 880 937 954];
mat_a = ones(length(x),2);
mat_a(:,1) = x';
previsao_4 = mat_a*c_a'
erro_4 = abs(y - previsao_4')
erro_quadratico_4 = ( (y(1) - previsao_4(1))^2 + (y(2) - previsao_4(2))^2 + (y(3) - previsao_4(3))^2 + (y(4) - previsao_4(4))^2 ) / 4
% LETRA B)
x = [0 1 2 3 4 5 6 7];
y = [151 180 200 240 260 300 350 380];
[c_b] = polyfit(x, y, 1);
mat_b = ones(length(x),2);
mat_b(:,1) = x';
x = [15 16 17 18];
y = [788 880 937 954];
mat_b = ones(length(x),2);
mat_b(:,1) = x';
previsao_8 = mat_b*c_b'
erro_8 = abs(y - previsao_8')
erro_quadratico_8 = ( (y(1) - previsao_8(1))^2 + (y(2) - previsao_8(2))^2 + (y(3) - previsao_8(3))^2 + (y(4) - previsao_8(4))^2 ) / 4
% LETRA C)
x = [0 1 2 3 4 5 6 7 8 9 10 11 12 13 14];
y = [151 180 200 240 260 300 350 380 415 465 510 545 622 678 724];
[c_c] = polyfit(x, y, 1);
mat_c = ones(length(x),2);
mat_c(:,1) = x';
x = [15 16 17 18];
y = [788 880 937 954];
mat_c = ones(length(x),2);
mat_c(:,1) = x';
previsao_15 = mat_c*c_c'
erro_15 = abs(y - previsao_15')
erro_quadratico_15 = ( (y(1) - previsao_15(1))^2 + (y(2) - previsao_15(2))^2 + (y(3) - previsao_15(3))^2 + (y(4) - previsao_15(4))^2 ) / 4
% GRAFICO
plot_ = ones(length(x), 4);
plot_(:,1) = previsao_4;
plot_(:,2) = previsao_8;
plot_(:,3) = previsao_15;
plot_(:,4) = y;
plot(x, plot_, '-*');
legend('4','8','15','Dados');